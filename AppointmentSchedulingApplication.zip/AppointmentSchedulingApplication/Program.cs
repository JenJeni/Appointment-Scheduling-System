﻿using AppointmentSchedulingApplication.DataAccess;
using AppointmentSchedulingApplication.DataModels;
using AppointmentSchedulingApplication.Views;
using System;
using System.Windows.Forms;

namespace AppointmentSchedulingApplication
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            //Create second user for testing
            User.CreateNewUser();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            ConnectDb.openConnection();

            Application.Run(new Login());

            ConnectDb.closeConnection();
        }
    }
}
